import os
import arabic_reshaper
import cv2  #Ensure cv2 is imported in this file
from my_functions import *
from variables import actions, frames
from PIL import ImageFont, ImageDraw, Image
from bidi.algorithm import get_display
import time

# Load the custom font
fontpath = "arial.ttf"
font = ImageFont.truetype(fontpath, 32)


def put_arabic_text(image, text, position, font, font_color=(0, 0, 255)):
    reshaped_text = arabic_reshaper.reshape(text)
    bidi_text = get_display(reshaped_text)
    pil_image = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(pil_image)
    draw.text(position, bidi_text, font=font, fill=font_color)
    return cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)


def start_recording(selected_action):
    sequences = 35
    start = 0
    end = start + sequences
    PATH = os.path.join('data')

    # Create directories for each action and sequence
    for sequence in range(start, end):
        try:
            os.makedirs(os.path.join(PATH, selected_action, str(sequence)), exist_ok=True)
        except Exception as e:
            print(f"خطأ في إنشاء الدليل: {e}")

    # Access and check the camera functionality
    try:
        cap = cv2.VideoCapture(0)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)  # تعيين عرض الكاميرا إلى 320 بكسل
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)  # تعيين ارتفاع الكاميرا إلى 240 بكسل

        if not cap.isOpened():
            raise RuntimeError("لا يمكن الوصول إلى الكاميرا.")
    except Exception as e:
        print(f"خطأ: {e}")
        return

    cv2.namedWindow('Camera', cv2.WINDOW_NORMAL)
    cv2.resizeWindow('Camera', 640, 480)  # Resize the camera window

    with mp.solutions.holistic.Holistic(min_detection_confidence=0.5,
                                        min_tracking_confidence=0.5) as holistic:  # Lower default values
        for sequence in range(start, end):
            print(f"التحضير لتسجيل الحركة: {selected_action}, التسلسل رقم: {sequence}")

            # Wait before starting the recording
            while True:
                ret, image = cap.read()
                if not ret:
                    print("فشل في التقاط الإطار")
                    continue

                # Display instructions to the user
                image = put_arabic_text(image, f'تسجيل بيانات للحركة "{selected_action}". التسلسل رقم {sequence}.',
                                        (20, 20), font)
                image = put_arabic_text(image, 'اضغط على "المسافة" لبدء التسجيل أو Q للخروج.', (20, 220), font)

                cv2.imshow('Camera', image)

                key = cv2.waitKey(1) & 0xFF
                if key == ord('q') or cv2.getWindowProperty('Camera', cv2.WND_PROP_VISIBLE) < 1:
                    print("تم إيقاف التسجيل.")
                    cap.release()
                    cv2.destroyAllWindows()
                    return  # Exit recording
                elif key == ord(' '):
                    print("بدء العد التنازلي...")

                    # Countdown loop before starting recording
                    for countdown in range(3, 0, -1):
                        ret, image = cap.read()
                        if not ret:
                            print("فشل في التقاط الإطار أثناء العد التنازلي")
                            continue

                        # Display countdown on the screen
                        image = put_arabic_text(image, f'التسجيل يبدأ بعد: {countdown}', (100, 100), font)
                        cv2.imshow('Camera', image)

                        # Wait for a second before moving to the next number in the countdown
                        cv2.waitKey(1000)

                    print("بدء التسجيل...")
                    break

            # تسجيل الإطارات للحركة الحالية
            for frame in range(frames):
                ret, image = cap.read()
                if not ret:
                    print("فشل في التقاط الإطار")
                    continue

                results = image_process(image, holistic)
                draw_landmarks(image, results)
                image = put_arabic_text(image, f'تسجيل بيانات للحركة "{selected_action}". التسلسل رقم {sequence}.',
                                        (20, 20), font)
                image = put_arabic_text(image, 'اضغط على "المسافة" لإنهاء التسجيل أو Q للخروج.', (20, 220), font)

                cv2.imshow('Camera', image)

                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    print("تم إيقاف التسجيل.")
                    cap.release()
                    cv2.destroyAllWindows()
                    return  # الخروج من التسجيل
                elif key == ord(' '):  # Stop recording when space is pressed again
                    print("تم إنهاء التسجيل لهذه الحركة.")
                    break

                # حفظ البيانات إذا كانت موجودة
                keypoints = keypoint_extraction(results)
                if keypoints is not None:
                    frame_path = os.path.join(PATH, selected_action, str(sequence), str(frame))
                    np.save(frame_path, keypoints)
                else:
                    print(
                        f"فشل في استخراج النقاط المرجعية للحركة: {selected_action}, التسلسل: {sequence}, الإطار: {frame}")

            print(f"الانتقال إلى الحركة التالية: {selected_action}.")

    cap.release()
    cv2.destroyAllWindows()
