import shutil

import customtkinter as ctk
import numpy as np
from tkinter import messagebox
from data_collection import start_recording
from variables import actions, frames
import os

class TranslatorApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Application window settings
        self.title("واجهة إدارة البرنامج")
        self.geometry("480x800")
        self.configure(bg='#1a1d29')

        # Apply dark theme
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")

        # Layout setup
        layout = ctk.CTkFrame(self, fg_color='#1a1d29')
        layout.pack(fill="both", expand=True, padx=10, pady=10)

        # Action management section
        label_font = ctk.CTkFont(size=18, weight="bold")
        button_font = ctk.CTkFont(size=18, weight="bold")

        self.label_actions = ctk.CTkLabel(layout, text="الكلمات", font=label_font, fg_color='#1a1d29')
        self.label_actions.pack(pady=10)

        self.checkbox_frame = ctk.CTkFrame(layout, fg_color='#1a1d29')
        self.checkbox_frame.pack(fill="both", expand=True, pady=10)

        # Buttons to add and remove actions
        buttons_frame = ctk.CTkFrame(layout, fg_color='#1a1d29')
        buttons_frame.pack(fill="x", pady=10)

        self.button_add_action = ctk.CTkButton(buttons_frame, text="إضافة", command=self.add_action, font=button_font)
        self.button_add_action.pack(pady=5, anchor="center")

        self.button_remove_action = ctk.CTkButton(buttons_frame, text="إزالة", command=self.remove_selected_actions,
                                                  font=button_font)
        self.button_remove_action.pack(pady=5, anchor="center")

        # Button to toggle selection for all words
        self.button_toggle_select = ctk.CTkButton(layout, text="تحديد", command=self.toggle_select_all,
                                                  font=button_font)
        self.button_toggle_select.pack(pady=10)

        # Frame count control slider
        self.label_frames = ctk.CTkLabel(layout, text=f"عدد الإطارات: {frames}", font=("Arial", 14), fg_color='#1a1d29')
        self.label_frames.pack(pady=10)

        self.frames_slider = ctk.CTkSlider(layout, from_=30, to=60, number_of_steps=30, command=self.update_frames,
                                           fg_color='#1a1d29')
        self.frames_slider.set(frames)
        self.frames_slider.pack(pady=10)

        # Button to start recording
        self.button_start_recording = ctk.CTkButton(layout, text="التسجيل", command=self.start_recording,
                                                    font=button_font)
        self.button_start_recording.pack(pady=10)

        # Button to run the model
        self.button_run_model = ctk.CTkButton(layout, text=" المودل تشغيل", command=self.run_model,
                                              font=button_font)
        self.button_run_model.pack(pady=10)

        # Button to return to the main page
        self.button_main_page = ctk.CTkButton(layout, text="خروج", command=self.go_to_main_page, font=button_font)
        self.button_main_page.pack(pady=10)

        # Load the action list into checkboxes
        self.update_actions_list()

        # Selection state
        self.all_selected = True

    def update_actions_list(self):
        """ Update the action list with checkboxes """
        for widget in self.checkbox_frame.winfo_children():
            widget.destroy()

        self.action_checkboxes = []
        for action in actions:
            var = ctk.StringVar(value=action)
            checkbox = ctk.CTkCheckBox(self.checkbox_frame, text=action, variable=var, onvalue=action, offvalue="",
                                       fg_color='#1a1d29')
            checkbox.pack(anchor="w", pady=5)
            self.action_checkboxes.append(checkbox)

    def add_action(self):
        """ Add a new action """
        global actions
        new_action = ctk.CTkInputDialog(text=": الجديدة الكلمة أدخل", title="الكلمة إضافة ").get_input()
        if new_action and new_action not in actions:
            actions = np.sort(np.append(actions, new_action))
            self.update_actions_list()
            self.save_variables_file()
            messagebox.showinfo("تمت الإضافة", "تمت إضافة الكلمة بنجاح!")
        else:
            messagebox.showwarning("الكلمة مكرر", "هذا الكلمة موجود بالفعل.")

    def remove_selected_actions(self):
        """ Remove selected actions """
        global actions
        selected_actions = [cb.cget("text") for cb in self.action_checkboxes if cb.get() == cb.cget("onvalue")]
        if selected_actions:
            confirm = messagebox.askyesno("تأكيد الحذف", f"هل تريد حذف {', '.join(selected_actions)}؟")
            if confirm:

                actions = np.array([action for action in actions if action not in selected_actions])
                self.update_actions_list()
                self.save_variables_file()
                messagebox.showinfo("تم الحذف", "تم حذف الكلمة المحددة.")
                data_folder = 'data'
                for action in selected_actions:
                    folder_path = os.path.join(data_folder, action)
                    if os.path.exists(folder_path) and os.path.isdir(folder_path):
                        shutil.rmtree(folder_path)
        else:
            messagebox.showwarning("خطأ", "الرجاء اختيار الكلمة لحذفه.")

    def toggle_select_all(self):
        """ Toggle selection state for all actions """
        if not self.all_selected:
            for checkbox in self.action_checkboxes:
                checkbox.select()
            self.button_toggle_select.configure(text="تحديد")
            self.all_selected = True
        else:
            for checkbox in self.action_checkboxes:
                checkbox.deselect()
            self.button_toggle_select.configure(text="تحديد")
            self.all_selected = False

    def update_frames(self, value):
        """ Update the number of frames """
        global frames
        frames = int(value)
        self.label_frames.configure(text=f"عدد الإطارات: {frames}")
        self.save_variables_file()

    def save_variables_file(self):
        """ Save settings to variables.py file """
        try:
            with open('variables.py', 'w', encoding='utf-8') as f:
                f.write("import numpy as np\n\n")
                f.write(f"actions = np.sort(np.array({actions.tolist()}))\n")
                f.write(f"frames = {frames}\n")
        except Exception as e:
            messagebox.showerror("خطأ", f"حدث خطأ أثناء حفظ الإعدادات: {e}")

    def start_recording(self):
        """ Start recording for selected actions """
        selected_actions = [cb.cget("text") for cb in self.action_checkboxes if cb.get() == cb.cget("onvalue")]
        if selected_actions:
            for action in selected_actions:
                start_recording(action)
            messagebox.showinfo("بدء التسجيل", f"بدأ التسجيل للأفعال: {', '.join(selected_actions)}")
        else:
            messagebox.showwarning("خطأ", "الرجاء تحديد الكلمة لبدء التسجيل.")

    def run_model(self):
        """ Run the model """
        try:
            os.system("python model.py")  # تشغيل ملف المودل
            messagebox.showinfo("تشغيل المودل", "تم تشغيل المودل بنجاح!")
        except Exception as e:
            messagebox.showerror("خطأ", f"حدث خطأ أثناء تشغيل المودل: {e}")

    def go_to_main_page(self):
        """ Close the application """
        self.destroy()


def main():
    window = TranslatorApp()
    window.mainloop()

if __name__ == "__main__":
    main()
