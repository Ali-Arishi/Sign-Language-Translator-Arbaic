import cv2
import customtkinter as ctk
from translation import Translator
import arabic_reshaper
from bidi.algorithm import get_display
import os
import threading  # Use threading instead of multiprocessing
import edit   # Ensure that edit.py is in the same directory

# Set CustomTkinter theme
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")


class TranslatorApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Window settings
        self.title("مترجم لغة الإشارة")
        self.geometry("480x800")
        self.configure(fg_color='#1a1d29')

        # Camera display
        self.camera_frame = ctk.CTkLabel(self, text="", fg_color='#1a1d29')
        self.camera_frame.pack(pady=10)

        # Translation output field
        self.translation_output = ctk.CTkLabel(self, text="", width=440, height=150,
                                               fg_color="#202124", corner_radius=10, text_color="#e8eaed",
                                               font=ctk.CTkFont(size=24, weight="bold"))
        self.translation_output.pack(pady=10)

        # Textbox for displaying records (hidden by default)
        self.record_textbox = ctk.CTkTextbox(self, width=440, height=150, fg_color="#202124", text_color="#e8eaed")
        self.record_textbox.pack(pady=10)
        self.record_textbox.pack_forget()  # Hide textbox initially


        # Control buttons
        button_font = ctk.CTkFont(size=18, weight="bold")   # Unified font for buttons


        self.start_button = ctk.CTkButton(self, text=self.format_text("ابدأ الترجمة"), command=self.start_translation,
                                          font=button_font)
        self.start_button.pack(pady=5, anchor="center")

        self.stop_button = ctk.CTkButton(self, text=self.format_text("إيقاف الترجمة"), command=self.stop_translation,
                                         font=button_font)
        self.stop_button.pack(pady=5, anchor="center")

        self.reset_button = ctk.CTkButton(self, text=self.format_text("إعادة التعيين"), command=self.reset_translation,
                                          font=button_font)
        self.reset_button.pack(pady=5, anchor="center")

        self.save_button = ctk.CTkButton(self, text=self.format_text("حفظ الترجمة"), command=self.save_translation,
                                         font=button_font)
        self.save_button.pack(pady=5, anchor="center")

        self.launch_ui_button = ctk.CTkButton(self, text=self.format_text("تشغيل واجهة التعديل"),
                                              command=self.launch_ui_process, font=button_font)
        self.launch_ui_button.pack(pady=5, anchor="center")

        # Button to toggle the display of the records list at the bottom
        self.toggle_button = ctk.CTkButton(self, text=self.format_text("عرض السجلات"), command=self.toggle_records,
                                           font=button_font)
        self.toggle_button.pack(pady=10, side="bottom")  # وضع الزر في أسفل النافذة

        # Camera setup
        self.cap = cv2.VideoCapture(0)
        self.update_camera_feed()

        # Translator object
        self.translator = Translator()

        # Frame counter
        self.frame_count = 0
        self.process_interval = 3

        # Load records from file
        self.load_records()

    def format_text(self, text):
        # Format text to support Arabic reshaping and bidirectional display
        reshaped_text = arabic_reshaper.reshape(text)
        return get_display(reshaped_text)

    def start_translation(self):
        # Start translation process
        self.translating = True
        self.update_camera_feed()

    def stop_translation(self):
        # Stop translation process
        self.translating = False

    def reset_translation(self):
        """Reset translation"""
        self.translation_output.configure(text="")
        self.translator.sentence = []
        self.record_textbox.delete("1.0", "end")
        self.frame_count = 0
        print("تمت إعادة تعيين الترجمة")

    def save_translation(self):
        # Save the current translation
        self.saved_translation = ' '.join(self.translator.sentence)
        reshaped_text = arabic_reshaper.reshape(self.saved_translation)
        final_text = get_display(reshaped_text)

        # Save the text to "record.txt"
        file_path = "record.txt"
        with open(file_path, 'a', encoding='utf-8') as file:
            file.write(final_text + '\n')
        print(f"تم حفظ الترجمة في: {file_path}")

        # Update the app UI with the saved text
        self.translation_output.configure(text=final_text)
        self.record_textbox.insert("end", final_text + "\n")  # إضافة النص إلى مربع النص

    def load_records(self):
        # Load contents of "record.txt" into the textbox on app startup
        if os.path.exists("record.txt"):
            with open("record.txt", 'r', encoding='utf-8') as file:
                for line in file:
                    self.record_textbox.insert("end", line.strip() + "\n")

    def toggle_records(self):
        # Show or hide the textbox
        if self.record_textbox.winfo_viewable():
            self.record_textbox.pack_forget()
            self.toggle_button.configure(text=self.format_text("عرض السجلات"))
        else:
            self.record_textbox.pack(pady=10)
            self.toggle_button.configure(text=self.format_text("إخفاء السجلات"))

    def launch_ui_process(self):
        """Launch edit.py UI in a separate thread"""
        thread = threading.Thread(target=edit.main)
        thread.start()

    def update_camera_feed(self):
        if not hasattr(self, 'translating') or not self.translating:
            return

        ret, frame = self.cap.read()
        if not ret:
            print("فشل في الحصول على الإطار")
            return

        frame = cv2.resize(frame, (320, 240))   # Reduce frame size to 320x240
        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        from PIL import Image, ImageTk
        img = Image.fromarray(image)
        imgtk = ImageTk.PhotoImage(image=img)
        self.camera_frame.configure(image=imgtk)
        self.camera_frame.image = imgtk

        if self.frame_count % self.process_interval == 0:
            self.translator.add_frame(frame)
            translated_text = self.translator.process_frame(frame)
            self.translation_output.configure(text=translated_text)

        self.frame_count += 1
        cv2.waitKey(50)
        self.after(20, self.update_camera_feed)


# Main function to run the app
def main():
    app = TranslatorApp()
    app.mainloop()


if __name__ == "__main__":
    main()
