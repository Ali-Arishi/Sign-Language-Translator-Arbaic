# Import necessary libraries
import numpy as np
import os
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical
from itertools import product
from sklearn import metrics
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, classification_report
import matplotlib.pyplot as plt
from variables import actions, frames

# Set the path to the data directory
PATH = os.path.join('data')

# Define the number of sequences and frames
sequences = 35
expected_features = 126  # Expected feature dimension for each frame

# Create a label map to map each action label to a numeric value
label_map = {label: num for num, label in enumerate(actions)}

# Initialize empty lists to store landmarks and labels
landmarks, labels = [], []

# Iterate over actions and sequences to load landmarks and corresponding labels
for action, sequence in product(actions, range(sequences)):
    temp = []
    for frame in range(frames):
        npy_path = os.path.join(PATH, action, str(sequence), str(frame) + '.npy')
        if os.path.exists(npy_path):
            npy = np.load(npy_path)
            # Pad or trim each frame to ensure it has exactly 126 features
            if npy.shape[0] < expected_features:
                npy = np.pad(npy, (0, expected_features - npy.shape[0]), mode='constant')
            elif npy.shape[0] > expected_features:
                npy = npy[:expected_features]
            temp.append(npy)

    # Ensure the sequence has the correct number of frames
    if len(temp) < frames:
        temp = np.pad(temp, ((0, frames - len(temp)), (0, 0)), mode='constant')
    elif len(temp) > frames:
        temp = np.array(temp[:frames])
    else:
        temp = np.array(temp)

    landmarks.append(temp)
    labels.append(label_map[action])

# Convert landmarks and labels to numpy arrays
X = np.array(landmarks)
Y = to_categorical(labels).astype(int)

# Split the data into training and testing sets
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.20, random_state=34, stratify=Y)

# Define the model architecture
model = Sequential()
model.add(LSTM(32, return_sequences=True, activation='relu', input_shape=(frames, expected_features)))
model.add(LSTM(64, return_sequences=True, activation='relu'))
model.add(LSTM(32, return_sequences=False, activation='relu'))
model.add(Dense(32, activation='relu'))
model.add(Dense(len(actions), activation='softmax'))

# Compile the model with Adam optimizer and categorical cross-entropy loss
model.compile(optimizer='Adam', loss='categorical_crossentropy', metrics=['categorical_accuracy'])

# Train the model
history = model.fit(X_train, Y_train, epochs=7100, validation_data=(X_test, Y_test))

# Save the trained model
model.save('best_model.h5')

# Plot Training and Validation Accuracy
plt.figure(figsize=(12, 5))

# Training and Validation Accuracy
plt.subplot(1, 2, 1)
plt.plot(history.history['categorical_accuracy'], label='Training Accuracy')
plt.plot(history.history['val_categorical_accuracy'], label='Validation Accuracy', linestyle='--')
plt.title('Training and Validation Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()

# Training and Validation Loss
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss', linestyle='--')
plt.title('Training and Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()

plt.tight_layout()
plt.show()

# Make predictions on the test set
predictions = np.argmax(model.predict(X_test), axis=1)
test_labels = np.argmax(Y_test, axis=1)

# Calculate the accuracy of the predictions
accuracy = metrics.accuracy_score(test_labels, predictions)
print(f"Test accuracy: {accuracy * 100:.2f}%")

# Create a Confusion Matrix
cm = confusion_matrix(test_labels, predictions)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=actions)

# Display the Confusion Matrix
disp.plot(cmap=plt.cm.Reds)
plt.title("Confusion Matrix")
plt.show()

# Generate a Classification Report
report = classification_report(test_labels, predictions, target_names=actions)
print("Classification Report:\n", report)
