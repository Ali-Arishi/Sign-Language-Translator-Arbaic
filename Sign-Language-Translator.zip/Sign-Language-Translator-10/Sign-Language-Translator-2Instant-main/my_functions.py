import mediapipe as mp
import cv2
import numpy as np

# Initialize Mediapipe drawing and holistic tools
mp_drawing = mp.solutions.drawing_utils
mp_holistic = mp.solutions.holistic

def draw_landmarks(image, results):

    # Draw landmarks for the head and arms only
    if results.pose_landmarks:
        upper_body_landmarks = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]  # الرأس والذراعين فقط
        for idx in upper_body_landmarks:
            landmark = results.pose_landmarks.landmark[idx]
            cv2.circle(image, (int(landmark.x * image.shape[1]), int(landmark.y * image.shape[0])), 5, (0, 255, 0), -1)

    # Draw landmarks for the left hand
    mp_drawing.draw_landmarks(image, results.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS)

    # Draw landmarks for the right hand
    mp_drawing.draw_landmarks(image, results.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS)

def image_process(image, model):

    # Set the image to read-only mode
    image.flags.writeable = True
    # Convert the image from BGR to RGB
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    # Process the image using the Mediapipe model
    results = model.process(image)
    # Reset the image to writable mode
    image.flags.writeable = True
    # Convert the image back from RGB to BGR
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    return results

def keypoint_extraction(results):

    # Extract landmarks for the left hand if available, otherwise set to zeros
    lh = np.array([[res.x, res.y, res.z] for res in results.left_hand_landmarks.landmark]).flatten() if results.left_hand_landmarks else np.zeros(63)

    # Extract landmarks for the right hand if available, otherwise set to zeros
    rh = np.array([[res.x, res.y, res.z] for res in results.right_hand_landmarks.landmark]).flatten() if results.right_hand_landmarks else np.zeros(63)

    # Extract landmarks for the head and arms only (excluding legs and lower torso)
    if results.pose_landmarks:
        pose_landmarks = np.array([[res.x, res.y, res.z] for res in results.pose_landmarks.landmark])
        # Select landmarks for the head and arms only
        upper_body = np.concatenate([pose_landmarks[0:11], pose_landmarks[15:23]])  # الرأس والذراعين فقط
        upper_body = upper_body.flatten()
    else:
        upper_body = np.zeros(66)  # Size for head and arms only (11 for head + 8 for arms)


    # Combine landmarks for the hands and upper body (excluding legs and lower torso)
    keypoints = np.concatenate([lh, rh, upper_body])
    return keypoints
