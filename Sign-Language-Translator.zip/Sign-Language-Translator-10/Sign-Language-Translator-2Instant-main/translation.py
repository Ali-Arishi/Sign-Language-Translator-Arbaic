import warnings

warnings.filterwarnings("ignore")  # Suppress warnings
import cv2
import numpy as np
import mediapipe as mp
from tensorflow.keras.models import load_model
from customtkinter import CTkImage
from PIL import Image
from my_functions import image_process, keypoint_extraction, draw_landmarks
from variables import actions, frames
import queue
import threading
import time
import arabic_reshaper
from bidi.algorithm import get_display  # For proper display of Arabic text


class Translator:
    def __init__(self):
        # Load the trained model
        self.model = load_model('best_model.h5')

        # Mediapipe setup
        self.holistic = mp.solutions.holistic.Holistic(min_detection_confidence=0.75, min_tracking_confidence=0.75)

        # Initialize variables
        self.sentence = []
        self.keypoints = []
        self.last_prediction = None
        self.frames_to_wait = frames  # Number of frames to collect before prediction
        self.current_translation = ""  # Stores the ongoing translation

        # Frame processing queue
        self.frame_queue = queue.Queue()
        self.processing_thread = threading.Thread(target=self.processing_loop)
        self.processing_thread.daemon = True
        self.processing_thread.start()

    def add_frame(self, frame):
        # Add frame to queue for processing
        self.frame_queue.put(frame.copy())

    def processing_loop(self):
        while True:
            if not self.frame_queue.empty():
                frame = self.frame_queue.get()
                self.process_frame(frame)
            else:
                time.sleep(0.01)

    def process_frame(self, frame):
        try:
            # Process the frame using Mediapipe to extract landmarks
            results = image_process(frame, self.holistic)
            draw_landmarks(frame, results)
            keypoints = keypoint_extraction(results)

            # Ensure that the landmarks contain 126 features
            expected_features = 126
            if keypoints is not None:
                if keypoints.shape[0] < expected_features:
                    keypoints = np.pad(keypoints, (0, expected_features - keypoints.shape[0]), mode='constant')
                elif keypoints.shape[0] > expected_features:
                    keypoints = keypoints[:expected_features]
                self.keypoints.append(keypoints)

            # Process prediction only after collecting sufficient frames
            if len(self.keypoints) == self.frames_to_wait:
                keypoints_sequence = np.array(self.keypoints)
                self.keypoints = []  # Reset after processing

                # Make prediction
                prediction = self.model.predict(keypoints_sequence[np.newaxis, :, :])

                # Analyze and update result
                if np.amax(prediction) > 0.8:  # Confidence threshold
                    predicted_action = actions[np.argmax(prediction)]
                    if self.last_prediction != predicted_action and predicted_action != 'blank':
                        self.sentence.append(predicted_action)
                        self.last_prediction = predicted_action

                # Limit sentence length for clear display
                if len(self.sentence) > 1:
                    self.sentence = self.sentence[-1:]

                # Format Arabic text after frame processing is complete
                reshaped_text = arabic_reshaper.reshape(' '.join(self.sentence))
                self.current_translation = get_display(reshaped_text)  # Update displayed translation

        except ValueError:
            # Ignore frame if there is a timestamp mismatch
            pass

        # Return current translation after processing
        return self.current_translation


# Example of how to use CTkImage instead of PIL.ImageTk.PhotoImage in UI setup
class TranslatorApp:
    def __init__(self, frame):
        # Load the image as CTkImage
        pil_image = Image.fromarray(frame)
        ctk_image = CTkImage(pil_image, size=(320, 240))

        # Set up the camera frame display using CTkImage (example)
        self.camera_frame = ctk_image
